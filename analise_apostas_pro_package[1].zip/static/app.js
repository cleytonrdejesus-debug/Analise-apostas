const configUrl = '/config';
async function loadConfig(){ const r = await fetch(configUrl); return await r.json(); }

function escapeHtml(s){ return String(s).replace(/[&<>"']/g, m=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;' }[m])); }

(async function(){
  const cfg = await loadConfig();
  const GOOGLE_CLIENT_ID = cfg.GOOGLE_CLIENT_ID || '';
  if(GOOGLE_CLIENT_ID){
    window.google.accounts.id.initialize({
      client_id: GOOGLE_CLIENT_ID,
      callback: handleCredentialResponse
    });
    window.google.accounts.id.renderButton(document.getElementById('gbtn'), { theme: 'outline', size: 'medium' });
    window.google.accounts.id.prompt();
  } else {
    document.getElementById('gbtn').innerHTML = '<div class="hint">Login Google desabilitado (defina GOOGLE_CLIENT_ID no Render)</div>';
  }

  const userEl = document.getElementById('user');
  function handleCredentialResponse(response){
    const payload = parseJwt(response.credential);
    userEl.classList.remove('hidden');
    userEl.innerHTML = `<img src="${escapeHtml(payload.picture)}" /> ${escapeHtml(payload.name)}`;
  }
  window.handleCredentialResponse = handleCredentialResponse;

  const ctx = document.getElementById('chart').getContext('2d');
  const chart = new Chart(ctx, {
    type: 'line',
    data: { labels: [], datasets: [{ label: 'Surebets detectadas', data: [], tension:0.3 }]},
    options: { responsive:true, scales:{ y:{ beginAtZero:true } } }
  });
  let sureCount = 0;

  const proto = location.protocol === 'https:' ? 'wss:' : 'ws:';
  const wsUrl = proto + '//' + location.host + '/ws';
  const ws = new WebSocket(wsUrl);
  const cards = document.getElementById('cards');
  const alerts = document.getElementById('alerts');
  const lastUpd = document.getElementById('lastupd');
  ws.onopen = ()=> console.log('ws open');
  ws.onmessage = (ev)=>{
    const data = JSON.parse(ev.data);
    renderItem(data);
    lastUpd.textContent = new Date(data.timestamp*1000).toLocaleTimeString();
    if(data.surebet){ sureCount += 1; document.getElementById('surecount').textContent = sureCount; addChartPoint(); showAlert(data); }
  };
  function addChartPoint(){ const now = new Date().toLocaleTimeString(); chart.data.labels.push(now); chart.data.datasets[0].data.push(sureCount); if(chart.data.labels.length>20){ chart.data.labels.shift(); chart.data.datasets[0].data.shift(); } chart.update(); }

  function showAlert(data){
    const d = document.createElement('div'); d.className='alert'; d.innerHTML = `<strong>Surebet!</strong> ${escapeHtml(data.match)} — lucro estimado: ${data.surebet.profit_on_100}`;
    alerts.prepend(d); setTimeout(()=>d.remove(),15000);
  }

  function renderItem(data){
    const key = btoa(unescape(encodeURIComponent(data.match+data.market))).replace(/=/g,'');
    let el = document.getElementById(key);
    if(!el){ el = document.createElement('div'); el.id = key; el.className='card'; cards.prepend(el); }
    el.innerHTML = `<h4>${escapeHtml(data.match)}</h4><div class="market">${escapeHtml(data.market)}</div>
      <table class="odds"><thead><tr><th>Runner</th><th>Bookmaker</th><th>Odd</th></tr></thead><tbody>${renderBest(data.best)}</tbody></table>
      ${data.surebet?'<div class="surebet">SUREBET! Lucro: '+data.surebet.profit_on_100+'</div>':''}
      <div class="ts">Atualizado: ${new Date(data.timestamp*1000).toLocaleTimeString()}</div>`;
  }
  function renderBest(best){ if(!best) return '<tr><td colspan=3>Sem dados</td></tr>'; return Object.keys(best).map(k=>`<tr><td>${escapeHtml(k)}</td><td>${escapeHtml(best[k][0])}</td><td>${escapeHtml(best[k][1])}</td></tr>`).join(''); }

  function parseJwt (token) {
    var base64Url = token.split('.')[1];
    var base64 = base64Url.replace(/-/g, '+').replace(/_/g, '/');
    var jsonPayload = decodeURIComponent(atob(base64).split('').map(function(c) {
        return '%' + ('00' + c.charCodeAt(0).toString(16)).slice(-2);
    }).join(''));
    return JSON.parse(jsonPayload);
  };
})();