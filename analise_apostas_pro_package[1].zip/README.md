Analise-Apostas Pro - Ready package for Render

How to deploy on Render:
1. Create a new Web Service -> Connect a GitHub repo or upload ZIP
2. If uploading ZIP, use this package and select Docker environment
3. IMPORTANT: set environment variable GOOGLE_CLIENT_ID to your Google OAuth Client ID

Google OAuth setup (simple client-side sign-in):
- Create OAuth 2.0 Client ID at https://console.cloud.google.com/apis/credentials
- Choose 'Web application' and add authorized origins like https://your-service.onrender.com
- Copy the Client ID and set it in Render as an env var named GOOGLE_CLIENT_ID

Notes:
- This package uses Google Identity Services client-side to authenticate users (client-only flow).
- For production, validate ID tokens server-side.
