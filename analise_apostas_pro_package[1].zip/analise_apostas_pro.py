"""
Analise-Apostas Pro - Backend
- Serves static SPA from /static
- WebSocket endpoint /ws (mock data stream)
- /config endpoint returns runtime config (GOOGLE_CLIENT_ID) from env variable
"""
import asyncio, os, time, random, json
from typing import Dict, Any, Tuple
from fastapi import FastAPI, WebSocket, WebSocketDisconnect
from fastapi.responses import JSONResponse
from fastapi.staticfiles import StaticFiles
import uvicorn

CONFIG = {
    "update_interval": float(os.getenv("UPDATE_INTERVAL", "0.8")),
    "bookmakers": ["BookA", "BookB", "BookC", "BookD"],
}

class MarketOdds:
    def __init__(self, match_id: str, market: str, runners: Dict[str, Dict[str, float]]):
        self.match_id = match_id
        self.market = market
        self.runners = runners
        self.timestamp = time.time()

class MockDataSource:
    def __init__(self, cfg):
        self.cfg = cfg
        self.matches = [
            ("Flamengo","Vasco"),
            ("Corinthians","Palmeiras"),
            ("Team A","Team B"),
            ("Alpha","Beta"),
            ("X","Y"),
            ("Real","Barca")
        ]
    async def stream(self):
        while True:
            home, away = random.choice(self.matches)
            match_id = f"{home} vs {away}"
            market = "1X2"
            runners = {"Home": {}, "Draw": {}, "Away": {}}
            for bm in self.cfg["bookmakers"]:
                h = round(random.uniform(1.5, 3.5), 2)
                d = round(random.uniform(2.5, 4.2), 2)
                a = round(random.uniform(2.0, 6.0), 2)
                if random.random() > 0.05: runners["Home"][bm] = h
                if random.random() > 0.25: runners["Draw"][bm] = d
                if random.random() > 0.15: runners["Away"][bm] = a
            mo = MarketOdds(match_id, market, runners)
            yield mo
            await asyncio.sleep(self.cfg["update_interval"])

app = FastAPI()
app.mount("/", StaticFiles(directory="static", html=True), name="static")

clients = []
async def broadcast(msg):
    living = []
    for ws in list(clients):
        try:
            await ws.send_json(msg)
            living.append(ws)
        except Exception:
            pass
    clients.clear()
    clients.extend(living)

@app.websocket("/ws")
async def ws_endpoint(ws: WebSocket):
    await ws.accept()
    clients.append(ws)
    try:
        while True:
            await ws.receive_text()
    except WebSocketDisconnect:
        if ws in clients: clients.remove(ws)

@app.get("/config")
def get_config():
    # Return config values available to the SPA (e.g., Google Client ID)
    google_client_id = os.getenv("GOOGLE_CLIENT_ID", "")
    return JSONResponse({"GOOGLE_CLIENT_ID": google_client_id})

@app.get("/health")
def health():
    return {"status":"ok","time":time.time()}

# Producer mock sending best prices and surebet detection
def best_prices(mo: MarketOdds):
    best = {}
    for runner, prices in mo.runners.items():
        if not prices: continue
        bm, odd = max(prices.items(), key=lambda x: x[1])
        best[runner] = (bm, odd)
    return best

def check_surebet(mo: MarketOdds):
    best = best_prices(mo)
    if not best: return {}
    inv_sum = 0.0
    details = []
    for runner,(bm,odd) in best.items():
        inv = 1.0/odd
        inv_sum += inv
        details.append({"runner":runner,"bookmaker":bm,"odd":odd,"inv":round(inv,6)})
    if inv_sum < 1.0:
        total = 100.0
        stakes = {d["runner"]: round(total*(d["inv"]/inv_sum),2) for d in details}
        profit = round(stakes[details[0]["runner"]]*details[0]["odd"] - total,2)
        return {"type":"surebet","inv_sum":round(inv_sum,6),"profit_on_100":profit,"details":details,"stakes":stakes}
    return {}

async def producer(cfg):
    ds = MockDataSource(cfg)
    async for mo in ds.stream():
        payload = {"match": mo.match_id, "market": mo.market, "best": best_prices(mo), "timestamp": mo.timestamp}
        sb = check_surebet(mo)
        if sb: payload["surebet"] = sb
        await broadcast(payload)

if __name__ == "__main__":
    import asyncio
    loop = asyncio.get_event_loop()
    loop.create_task(producer(CONFIG))
    uvicorn.run("analise_apostas_pro:app", host="0.0.0.0", port=8000, log_level="info")
